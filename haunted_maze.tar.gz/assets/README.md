# Haunted Maze

A Halloween maze game in Python/Pygame for Ms. Qui's Unit 3 project, built to the **Advanced** level. The extension is **second-order (2-gram) Markov prediction**.

You're a pumpkin kid trapped in a haunted maze. Collect candy to unlock the exit, use potions to scare the ghosts away, and try to escape before the **Pumpkin King** learns how you move and gets in your way.

## How to run

**Desktop:** `pip install pygame`, then `python main.py` from inside this folder.

**Web (pygbag):** from the folder *above* this one, run `pygbag haunted_maze`. Then upload the contents of `haunted_maze/build/web` to the GitHub Pages repo.

There are no image or sound files. Everything is drawn with Pygame shapes.

## Controls

| Key | Action |
|---|---|
| Arrow keys / WASD | Move (on the setup screen: pick an item and change its probability) |
| F or TAB | Turn AI Debug Mode on or off (works anywhere) |
| N | New maze (setup screen) |
| ENTER | Start / continue |
| R | Play again after winning or losing |
| ESC | Back to setup / quit (desktop only) |

## Objective and rules

- Collect **half of the spawned candy** to open the exit (the red ring turns green), then reach it to win.
- You have **3 lives**. You lose one when a ghost or the Pumpkin King touches you, or when you step on poison. After a hit, everyone goes back to their spawn and you blink for 2 seconds of safety.
- **Potion:** ghosts flee for 6 seconds. Touch a fleeing ghost to banish it (+50 points). The Pumpkin King isn't scared of potions.
- **Spider:** you're stuck in a web for 1.5 seconds.
- **Mud / thorns:** cost 2 / 3. They slow down *everyone*, and A* plans around them.

## AI techniques used

| Requirement | Where it lives | What it does |
|---|---|---|
| A. Procedural maze | `maze.py` → `carve_maze` | DFS recursive backtracking (an explicit stack instead of Python recursion), then `add_loops` knocks out 12% of thin walls so there are alternate routes to predict and ambush. Every spawn is checked against a BFS reachability map. The exit goes on the farthest reachable cell. |
| B. Probability world | Setup screen + `World.spawn_items` | You set the probability for candy, potion, spider and poison. Each eligible cell gets one roll against those probabilities. The preview re-rolls live and shows expected vs. actually spawned counts. |
| C. Player | `agents.py` → `Player` | Grid movement with smooth sliding. Terrain costs slow you down too. |
| D. Small NPC FSM | `ghost.py` | 4 states: PATROL, CHASE, SEARCH, FLEE. Every state navigates with A*. CHASE re-plans only when the player enters a new cell (event-driven, from Lesson 11). |
| E. A* | `pathfinding.py` → `astar` | Weighted A* with a Manhattan heuristic. Every terrain costs at least 1, so the heuristic is admissible and the path is optimal. It reconstructs the path through `came_from`. |
| F. Markov | `markov.py` | 1st-order counts `P(next | last)` **and** 2nd-order counts `P(next | last two)`, with add-one smoothing and only open directions allowed. |
| G. Boss | `boss.py` | STALK → AMBUSH → POUNCE. AMBUSH predicts 8 steps ahead with a beam search, scores every predicted cell with a utility, and takes A* to the best one. |
| H. Debug Mode | `debug.py` | Ghost states, the reason for each state, targets and paths. The Boss's predicted cells, top 5 candidates with their utility breakdown, chosen target and A* path. Next-move probability arrows on the player. The 1st-order transition count matrix, which model is being used, and live prediction accuracy (overall and at junctions). |
| I. Game loop | `main.py` | Title → setup → play → win/lose → restart. |

### Boss utility

```
U = 40 * p  -  0.6 * cost  -  4 * late
```

- `p`: the chance the player passes through the cell within 8 steps.
- `cost`: the Boss's travel cost to the cell, from one Dijkstra flood.
- `late`: how many player-steps behind the player the Boss would arrive (0 if it gets there first).

Chasing the player's current cell is always one of the candidates, so the Boss only ambushes when the ambush scores higher.

## Extension: 2-gram prediction

The 2nd-order model is only used once its two-move context has been seen at least 3 times. Before that, it backs off to the 1st-order model (and to a uniform guess when there's no data). Both models make a guess before every move, so Debug Mode can compare them live. The **junction** score only counts cells with 3 or more exits, where guessing is actually hard.

I tested both models with simulated players:

| Simulated player habit | Junction choices | 1st-order accuracy | 2nd-order accuracy |
|---|---|---|---|
| Habit depends on the last move only | ~100 per game | 70–91% | about the same (±2%) |
| Habit depends on the last **two** moves ("after two straight moves, turn left; after a turn, go straight") | 1,960 | 55% | **66%** |

The 2-gram model only helps when a habit actually depends on two moves. Otherwise it ties the 1st-order model, because it backs off to it.

## Known limitations

- The Markov model only remembers directions, not *where* in the maze you are. It can't learn things like "they always go left at this specific junction."
- In corridors there's only one way forward, so overall accuracy looks high (around 94%). The junction score is the honest one.
- The Pumpkin King is tuned to be tough. Players who never look at it get caught a lot.
- Both ghosts can sometimes pick the same patrol area and travel together.
- After you lose a life you're moved back to the start. The model still treats your next move as if it followed your last one.
- I didn't test the pygbag web build on my machine. The code follows pygbag's rules (async main loop, no threads, default font), but test it before submitting.

## Files

`main.py` (game loop and screens), `config.py` (all tuning numbers), `maze.py`, `pathfinding.py`, `agents.py`, `ghost.py`, `boss.py`, `markov.py`, `render.py`, `debug.py`, `ai_design_diagram.png`, `DESIGN.md`, `REFLECTION_DRAFT.md`
