"""Grid movement shared by the player and every NPC.

Each agent stands on one logical cell. A move into a neighbor takes
step_frames * terrain cost frames, and the drawing slides between the two cells."""
from config import TERRAIN_COST, CELL, PLAYER_STEP, START_LIVES, DIRS


class Mover:
    def __init__(self, cell, step_frames):
        self.cell = cell
        self.prev = cell
        self.step_frames = step_frames
        self.move_left = 0          # frames until the current move finishes
        self.move_total = 1

    @property
    def moving(self):
        return self.move_left > 0

    def begin_move(self, world, nxt):
        self.prev = self.cell
        self.cell = nxt             # the logical cell changes immediately
        self.move_total = self.step_frames * TERRAIN_COST[world.terrain(nxt)]
        self.move_left = self.move_total

    def tick_move(self):
        if self.move_left > 0:
            self.move_left -= 1
            if self.move_left == 0:
                self.prev = self.cell

    def pixel_pos(self):
        t = 1 - self.move_left / self.move_total if self.moving else 1
        x = self.prev[0] + (self.cell[0] - self.prev[0]) * t
        y = self.prev[1] + (self.cell[1] - self.prev[1]) * t
        return int(x * CELL + CELL / 2), int(y * CELL + CELL / 2)


class Player(Mover):
    def __init__(self, cell):
        super().__init__(cell, PLAYER_STEP)
        self.lives = START_LIVES
        self.score = 0
        self.candy = 0
        self.stuck = 0              # frames left stuck in a spider web
        self.potion = 0             # frames left of ghost repellent
        self.grace = 0              # frames of invulnerability after a hit
        self.last_dir = None

    def try_step(self, world, direction):
        """Returns the direction actually taken (for the Markov model) or None."""
        if self.moving or self.stuck > 0 or direction is None:
            return None
        dx, dy = DIRS[direction]
        nxt = (self.cell[0] + dx, self.cell[1] + dy)
        if not world.walkable(nxt):
            return None
        self.begin_move(world, nxt)
        self.last_dir = direction
        return direction

    def tick(self):
        self.tick_move()
        for attr in ("stuck", "potion", "grace"):
            if getattr(self, attr) > 0:
                setattr(self, attr, getattr(self, attr) - 1)


class PathFollower(Mover):
    """An NPC that walks along a list of cells produced by A*."""

    def __init__(self, cell, step_frames):
        super().__init__(cell, step_frames)
        self.path = []              # remaining cells to walk (not including the current cell)
        self.target = None
        self.last_search = None     # SearchResult, for Debug Mode
        self.replans = 0

    def set_path(self, result):
        self.last_search = result
        self.target = result.goal
        self.path = result.path[1:] if result.found else []
        self.replans += 1

    def follow(self, world):
        if not self.moving and self.path:
            self.begin_move(world, self.path.pop(0))
        self.tick_move()

    @property
    def arrived(self):
        return not self.path and not self.moving
