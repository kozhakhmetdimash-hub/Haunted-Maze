"""Shared settings for Haunted Maze. Change numbers here to tune the game."""

# ---------------- screen / grid ----------------
CELL = 28
COLS, ROWS = 27, 19                 # odd numbers so the DFS carver lines up
GRID_W, GRID_H = COLS * CELL, ROWS * CELL
PANEL_W = 344                       # side panel (HUD + debug info)
BAR_H = 44                          # bottom bar
WIDTH, HEIGHT = GRID_W + PANEL_W, GRID_H + BAR_H
FPS = 60

# ---------------- terrain ----------------
WALL, FLOOR, MUD, THORNS = "wall", "floor", "mud", "thorns"
TERRAIN_COST = {FLOOR: 1, MUD: 2, THORNS: 3}   # cost of ENTERING a cell (walls can't be entered)
MUD_PATCHES, THORN_PATCHES = 6, 4
EXTRA_OPENINGS = 0.12               # fraction of removable walls knocked out to create loops

# ---------------- items (probability-based world) ----------------
CANDY, POTION, SPIDER, POISON = "candy", "potion", "spider", "poison"
ITEM_ORDER = [CANDY, POTION, SPIDER, POISON]
ITEM_INFO = {
    CANDY:  ("Candy",  "reward", "collect to unlock the exit (+10)"),
    POTION: ("Potion", "reward", "ghosts flee for 6 s; touch them to banish (+50)"),
    SPIDER: ("Spider", "hazard", "webbed: stuck for 1.5 s"),
    POISON: ("Poison", "hazard", "lose 1 life"),
}
DEFAULT_PROB = {CANDY: 0.08, POTION: 0.02, SPIDER: 0.04, POISON: 0.02}
PROB_STEP = 0.01
PROB_MAX_EACH = 0.30
PROB_MAX_TOTAL = 0.60
CANDY_NEEDED_FRACTION = 0.5         # share of spawned candy you must collect

# ---------------- timing (frames per cell on floor; multiplied by terrain cost) ----------------
PLAYER_STEP = 8
GHOST_STEP = 13
GHOST_FLEE_STEP = 16
BOSS_STEP = 11
POTION_FRAMES = 6 * FPS
WEB_FRAMES = int(1.5 * FPS)
HIT_GRACE_FRAMES = 2 * FPS          # invulnerable after losing a life
START_LIVES = 3

# ---------------- small ghost FSM ----------------
SIGHT_RANGE = 7                     # straight-line corridor vision
HEAR_RANGE = 2                      # Manhattan distance ghosts "hear" you
LOSE_SIGHT_FRAMES = 2 * FPS         # CHASE -> SEARCH after this long without seeing you
SEARCH_LOOK_FRAMES = 2 * FPS        # time spent looking around the last known cell
PATROL_RADIUS = 8

# ---------------- Markov prediction ----------------
DIRS = {"U": (0, -1), "D": (0, 1), "L": (-1, 0), "R": (1, 0)}
DIR_NAMES = ["U", "D", "L", "R"]
SECOND_ORDER_MIN = 3                # need this many observations of a 2-gram context to trust it
PREDICT_HORIZON = 8                 # how many player steps ahead the Boss looks
BEAM_WIDTH = 6                      # how many predicted futures are kept per step

# ---------------- Boss ----------------
BOSS_MIN_OBS = 6                    # moves to observe before switching from STALK to AMBUSH
POUNCE_RANGE = 4                    # A* steps: closer than this, just go for the player
W_PROB = 40.0                       # utility weight for prediction probability
W_COST = 0.6                        # utility penalty per unit of Boss travel cost
W_LATE = 4.0                        # utility penalty per step the Boss would arrive late
LURK_FRAMES = 3 * FPS               # how long the Boss waits at an ambush cell

# ---------------- colors ----------------
BG = (14, 12, 22)
WALL_C = (34, 28, 52)
WALL_EDGE = (58, 48, 86)
FLOOR_C = (64, 58, 78)
MUD_C = (92, 66, 44)
THORNS_C = (52, 84, 52)
EXIT_LOCKED = (110, 60, 60)
EXIT_OPEN = (90, 230, 140)
PLAYER_C = (255, 168, 40)
GHOST_COLORS = [(170, 220, 255), (210, 170, 255)]
BOSS_C = (230, 50, 70)
TEXT = (232, 228, 245)
DIM = (150, 142, 172)
ACCENT = (255, 196, 80)
GOOD = (110, 230, 150)
BAD = (255, 110, 110)
PANEL_BG = (22, 18, 34)
