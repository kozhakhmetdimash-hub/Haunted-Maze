"""AI Debug Mode: draws what the NPCs are thinking on the maze and in the side panel."""
import pygame

from config import CELL, GRID_W, PANEL_W, DIR_NAMES, DIRS, BOSS_C, TEXT, DIM, ACCENT, GOOD, BAD
from markov import valid_dirs
from render import cell_center, text

STATE_COLOR = {"PATROL": (150, 200, 255), "CHASE": BAD, "SEARCH": ACCENT, "FLEE": (120, 140, 255),
               "STALK": ACCENT, "AMBUSH": (255, 90, 200), "POUNCE": BAD}


def draw_path(surf, start_px, path, color, width=3):
    pts = [start_px] + [cell_center(c) for c in path]
    if len(pts) >= 2:
        pygame.draw.lines(surf, color, False, pts, width)


def draw_x(surf, cell, color):
    cx, cy = cell_center(cell)
    pygame.draw.line(surf, color, (cx - 7, cy - 7), (cx + 7, cy + 7), 3)
    pygame.draw.line(surf, color, (cx + 7, cy - 7), (cx - 7, cy + 7), 3)


def draw_overlay(surf, game, small):
    world, player, model, boss = game.world, game.player, game.model, game.boss

    # --- Boss prediction: every predicted cell, brighter = more likely ---
    layer = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
    for t, beams in boss.prediction.items():
        for cell, prob, _ in beams:
            cx, cy = cell_center(cell)
            pygame.draw.circle(layer, (255, 90, 200, int(40 + 180 * min(1, prob * 1.5))), (cx, cy), 5)
    # most likely predicted route (top beam at the horizon)
    if boss.prediction:
        top = boss.prediction[max(boss.prediction)][0][2]
        pts = [cell_center(c) for c in top]
        pygame.draw.lines(layer, (255, 90, 200, 150), False, pts, 2)
    surf.blit(layer, (0, 0))

    # --- Boss candidates: numbered by rank, chosen one ringed ---
    for i, c in enumerate(boss.candidates[:5]):
        cx, cy = cell_center(c.cell)
        pygame.draw.circle(surf, (255, 255, 255), (cx, cy), 8, 1)
        text(surf, small, str(i + 1), (cx + 6, cy - 14), (255, 255, 255))
    if boss.target:
        cx, cy = cell_center(boss.target)
        pygame.draw.circle(surf, BOSS_C, (cx, cy), CELL // 2, 3)
    draw_path(surf, boss.pixel_pos(), boss.path, BOSS_C, 3)

    # --- Ghosts: path, target, state label ---
    for g in game.ghosts:
        draw_path(surf, g.pixel_pos(), g.path, g.color, 2)
        if g.target and g.path:
            draw_x(surf, g.target, g.color)
        gx, gy = g.pixel_pos()
        text(surf, small, g.state, (gx, gy - 20), STATE_COLOR[g.state], center=True)
        if g.sees:
            pygame.draw.line(surf, (255, 80, 80), (gx, gy), player.pixel_pos(), 1)
    bx, by = boss.pixel_pos()
    text(surf, small, boss.state, (bx, by - 22), STATE_COLOR[boss.state], center=True)

    # --- next-move probabilities as arrows around the player ---
    valid = valid_dirs(world, player.cell)
    dist, _ = model.distribution(model.history[-2:], valid)
    px, py = cell_center(player.cell)
    for d, p in dist.items():
        dx, dy = DIRS[d]
        length = 6 + 26 * p
        end = (px + dx * length, py + dy * length)
        pygame.draw.line(surf, (255, 255, 120), (px, py), end, 3)
        text(surf, small, f"{p:.0%}", (end[0] + dx * 10, end[1] + dy * 8), (255, 255, 160), center=True)


def draw_panel(surf, game, font, small, top=8):
    world, model, boss = game.world, game.model, game.boss
    x0 = GRID_W + 10
    y = top
    y = text(surf, font, "AI DEBUG MODE  (F / TAB to hide)", (x0, y), ACCENT) + 4

    # ghosts
    for g in game.ghosts:
        tgt = g.target if g.path else "-"
        y = text(surf, small, f"{g.name}: ", (x0, y), g.color)
        text(surf, small, f"{g.state}", (x0 + 60, y - 13), STATE_COLOR[g.state])
        y = text(surf, small, f"  why: {g.reason}   target {tgt}   path {len(g.path)}", (x0, y), DIM)
    y += 4

    # boss
    s = boss.last_search
    y = text(surf, small, "PUMPKIN KING (Boss)", (x0, y), BOSS_C)
    text(surf, small, boss.state, (x0 + 140, y - 13), STATE_COLOR[boss.state])
    y = text(surf, small, f"  why: {boss.reason}", (x0, y), DIM)
    if s:
        y = text(surf, small, f"  A* to {s.goal}: cost {s.cost}  path {len(s.path)}  explored {s.explored}"
                 f"  h(start)={s.h}", (x0, y), DIM)
    y = text(surf, small, f"  decisions made: {boss.decisions}", (x0, y), DIM) + 3

    if boss.candidates:
        y = text(surf, small, " #  cell      t   prob  cost  late  utility", (x0, y), TEXT)
        for i, c in enumerate(boss.candidates[:5]):
            color = GOOD if c is boss.choice else DIM
            y = text(surf, small, f" {i + 1}  {str(c.cell):<9} {c.t:>2}  {c.prob:5.2f}  {c.boss_cost:>4}"
                     f"  {c.late:4.1f}  {c.utility:7.1f}", (x0, y), color)
        y = text(surf, small, "  U = 40*prob - 0.6*cost - 4*late", (x0, y), DIM) + 3

    # markov
    valid = valid_dirs(world, game.player.cell)
    ctx = model.history[-2:]
    dist, used = model.distribution(ctx, valid)
    y = text(surf, small, "MARKOV PREDICTION", (x0, y), (255, 90, 200))
    y = text(surf, small, f"  last moves: {' '.join(model.history[-8:]) or '-'}", (x0, y), DIM)
    y = text(surf, small, f"  context {''.join(ctx) or '-'} -> using {used} model", (x0, y), DIM)
    y = text(surf, small, "  next: " + "   ".join(f"{d} {dist[d]:.0%}" for d in DIR_NAMES if d in dist),
             (x0, y), (255, 255, 160))
    a1, a2 = model.accuracy("1st"), model.accuracy("2nd")
    acc = (f"  accuracy 1st {a1:.0%}  2nd {a2:.0%}  ({model.tests} moves)" if a1 is not None
           else "  accuracy: no moves yet")
    y = text(surf, small, acc, (x0, y), GOOD)
    j = model.junction
    if j["tests"]:
        y = text(surf, small, f"  at junctions: 1st {j['1st'] / j['tests']:.0%}  2nd "
                 f"{j['2nd'] / j['tests']:.0%}  ({j['tests']} choices)", (x0, y), GOOD)
    y += 3

    # first-order transition counts
    y = text(surf, small, "  1st-order counts  (row = last, col = next)", (x0, y), DIM)
    y = text(surf, small, "        " + "    ".join(DIR_NAMES), (x0, y), TEXT)
    for a in DIR_NAMES:
        row = model.counts1[a]
        y = text(surf, small, f"     {a}  " + "".join(f"{row[b]:>5}" for b in DIR_NAMES), (x0, y), DIM)
    return y
