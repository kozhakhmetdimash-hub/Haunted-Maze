# Reflection (DRAFT: rewrite in your own words)

> This draft is based on what actually came up while the game was being built and tested. Replace anything that doesn't match your own experience, especially in "What failed," with what happened when *you* played and changed it.

**What was your most important AI design decision?**

Making the Boss score *cells* instead of just picking the most likely next move. At first the Boss went toward the single most likely predicted cell. But the most likely cell is usually right next to the player, so the Boss arrived too late every time and basically turned into a chaser. Now every cell on a predicted future is a candidate. Each one gets a probability (the chance the player passes through it) and a time (how many steps until they'd get there). The utility rewards high probability and punishes cells the Boss can't reach in time. Chasing the player is one of the candidates too, so the Boss only ambushes when ambushing actually scores better. That one formula is what makes it a Boss instead of a fast ghost, and Debug Mode shows each part of it.

**What failed during development?**

The 2-gram extension didn't help at first. With simulated players whose habits only depended on their last move, the 2-gram model's accuracy was the same as the 1st-order model's. Overall accuracy was also misleadingly high, around 94%. That's because in a corridor there's only one way forward, so any model gets it right. I fixed the measurement by adding a separate accuracy score that only counts junctions (3 or more exits). Then I tested with a player whose habit depends on two moves ("after two straight moves, turn left"). There the 2-gram model won 66% to 55%. The lesson was that the extension only helps when the behavior really has two-step patterns, and that I needed the right test to show it.

The first version of the Boss's candidate scoring also used the probability of being at a cell at *exactly* step t. Those numbers came out tiny (around 0.07), so the travel-cost penalty outweighed them and the Boss always picked the closest cell. Switching to "the chance the player passes through this cell at any point in the next 8 steps" fixed the balance.

**What would you improve with one more week?**

Add the player's position to the Markov state (for example, the junction they're standing at plus their direction), so the Boss could learn things like "they always go left at this specific junction." I'd also run the experiment from the extension menu: play many rounds with the Boss in plain-chase mode vs. ambush mode and compare how often each one catches the player. Finally, I'd tune the utility weights from that data instead of picking them by hand.

---

# 60–90 second Debug Mode explanation script

Press **F** first so Debug Mode is on the whole time.

1. **(0:00) World.** "Each maze is generated with DFS recursive backtracking, plus extra openings so there are loops. Before playing, I set the candy, potion, spider and poison probabilities. Watch the spawned counts change when I raise candy." *(Hold RIGHT on Candy.)*
2. **(0:15) Ghost FSM.** "This ghost is in PATROL, and its label and A* path are drawn on it. When it sees me down this corridor, the red sight line appears and it switches to CHASE. Its path re-plans only when I move into a new cell. If I break line of sight for 2 seconds, it goes to SEARCH at my last known spot." *(Lead a ghost around a corner.)*
3. **(0:35) Markov.** "These yellow arrows are the model's prediction for my next move. In the panel you can see my last moves, whether it's using the 2nd-order or the 1st-order model, and its accuracy, including just at junctions."
4. **(0:50) Trace one Boss decision.** "The Pumpkin King is in AMBUSH. It rolled my predicted path 8 steps ahead. Those pink dots are the predictions. Candidate 1 in the table is cell ___, which I reach in ___ steps with ___% probability. Its travel cost is ___ and it's late by 0, so its utility is the highest. That's why the red ring is there and its A* path goes there instead of toward me."
5. **(1:10) Wrap up.** "So the FSM decides *what* each NPC wants, A* decides *how* to get there, probability shapes the world, and the Markov model plus the utility score decide *where* the Boss should be."
