"""The Boss (the Pumpkin King): predicts where the player is going and tries to get there first.

States
  STALK  : not enough data on the player yet -> A* straight to the player
  AMBUSH : predict -> generate candidate cells -> score them -> A* to the best one, then lurk
  POUNCE : player is within POUNCE_RANGE steps -> A* straight to the player

Decision pipeline (runs every time the player enters a new cell, i.e. new data arrives):
  1. observe the move        (main game -> MarkovPredictor.observe)
  2. update the model        (MarkovPredictor counts)
  3. predict future cells    (MarkovPredictor.predict_paths, beam search)
  4. generate candidates     (every predicted cell, with the step t when the player gets there)
  5. score each candidate    (utility = probability - travel cost - lateness)
  6. select the best target
  7. navigate with A*
"""
from config import (BOSS_STEP, PLAYER_STEP, BOSS_MIN_OBS, POUNCE_RANGE, W_PROB, W_COST, W_LATE,
                    LURK_FRAMES)
from agents import PathFollower
from pathfinding import astar, dijkstra_costs

STALK, AMBUSH, POUNCE = "STALK", "AMBUSH", "POUNCE"


class Candidate:
    def __init__(self, cell, t, prob, boss_cost):
        self.cell, self.t, self.prob, self.boss_cost = cell, t, prob, boss_cost
        # convert the Boss's travel cost into "player steps" so the two times can be compared
        self.boss_steps = boss_cost * BOSS_STEP / PLAYER_STEP
        self.late = max(0.0, self.boss_steps - t)
        self.utility = W_PROB * prob - W_COST * boss_cost - W_LATE * self.late


class Boss(PathFollower):
    def __init__(self, cell):
        super().__init__(cell, BOSS_STEP)
        self.spawn = cell
        self.state = STALK
        self.reason = "no data yet"
        self.candidates = []            # scored candidates from the last decision (for Debug Mode)
        self.choice = None
        self.prediction = {}            # beam-search output from the last decision
        self.lurk = 0
        self.decisions = 0

    def reset(self):
        self.cell = self.prev = self.spawn
        self.move_left = 0
        self.path, self.candidates, self.choice = [], [], None
        self.state, self.reason = STALK, "respawned"
        self._checked_from = None

    def update(self, world, player, model, player_moved):
        # distance check only when someone changed cell (saves work in the browser build)
        if player_moved or self.cell != getattr(self, "_checked_from", None):
            self._checked_from = self.cell
            self._to_player = astar(world, self.cell, player.cell)
        player_dist = self._to_player
        steps_away = len(player_dist.path) - 1 if player_dist.found else 999

        if steps_away <= POUNCE_RANGE:
            self.state, self.reason = POUNCE, f"player {steps_away} steps away"
            if player_moved or not self.path:
                self.set_path(player_dist)
        elif model.observations < BOSS_MIN_OBS:
            self.state, self.reason = STALK, f"learning ({model.observations}/{BOSS_MIN_OBS} moves seen)"
            if player_moved or not self.path:
                self.set_path(player_dist)
        else:
            if self.state != AMBUSH:
                self.state, self.reason = AMBUSH, "model ready"
                self.decide(world, player, model)
            elif player_moved:
                self.decide(world, player, model)          # new data arrived: re-evaluate
            elif self.arrived:
                self.lurk -= 1                              # wait in ambush...
                if self.lurk <= 0:
                    self.decide(world, player, model)       # ...then re-evaluate anyway
        self.follow(world)

    def decide(self, world, player, model):
        """Steps 3-7 of the pipeline."""
        self.decisions += 1
        self.prediction = model.predict_paths(world, player.cell)
        travel = dijkstra_costs(world, self.cell)          # Boss cost to every cell, one search

        # 4. candidates: every cell on a predicted future. Its probability is the chance the
        #    player passes through it within the horizon (sum over the futures that contain it),
        #    and t is the first step at which the player would get there.
        final = self.prediction[max(self.prediction)]
        total = sum(p for _, p, _ in final) or 1
        pass_prob, first_t = {}, {}
        for _, prob, path in final:
            for t, cell in enumerate(path[1:], start=1):
                if cell in path[1:t]:
                    continue                       # count each future once per cell
                pass_prob[cell] = pass_prob.get(cell, 0) + prob / total
                first_t[cell] = min(first_t.get(cell, t), t)
        best = {}
        for cell, prob in pass_prob.items():
            if cell in travel and cell != player.cell:
                best[cell] = Candidate(cell, first_t[cell], prob, travel[cell])   # 5. score
        best[player.cell] = Candidate(player.cell, 0, 1.0, travel.get(player.cell, 999))  # plain chase option

        self.candidates = sorted(best.values(), key=lambda c: -c.utility)
        self.choice = self.candidates[0]
        self.set_path(astar(world, self.cell, self.choice.cell))
        self.lurk = LURK_FRAMES
        if self.choice.t == 0:
            self.reason = "chasing beats every ambush cell"
        else:
            self.reason = f"ambush: {self.choice.prob:.0%} chance player passes in ~{self.choice.t} steps"
