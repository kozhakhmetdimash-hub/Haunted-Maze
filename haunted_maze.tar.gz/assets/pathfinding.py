"""A* (used for all NPC navigation) and a Dijkstra cost map (used by the Boss to score candidates)."""
import heapq

from config import TERRAIN_COST


def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


class SearchResult:
    """What one A* search produced, kept so Debug Mode can show it."""

    def __init__(self, start, goal, path, cost, explored, g, h):
        self.start, self.goal = start, goal
        self.path = path            # list of cells from start to goal ([] if unreachable)
        self.cost = cost            # total terrain cost of the path
        self.explored = explored    # number of cells taken off the frontier
        self.g = g                  # g value of the goal (cost so far)
        self.h = h                  # h value at the start (heuristic estimate)

    @property
    def found(self):
        return bool(self.path)


def reconstruct(came_from, goal):
    path, cur = [], goal
    while cur is not None:
        path.append(cur)
        cur = came_from[cur]
    path.reverse()
    return path


def astar(world, start, goal, costs=TERRAIN_COST):
    """Weighted A*. f = g + h, where g is the terrain cost so far and h is Manhattan distance.
    Every terrain costs at least 1 per step, so Manhattan never overestimates (admissible),
    which means A* still returns the cheapest path."""
    if not world.walkable(goal):
        return SearchResult(start, goal, [], None, 0, None, manhattan(start, goal))
    frontier = [(manhattan(start, goal), 0, start)]
    came_from = {start: None}
    g_score = {start: 0}
    closed = set()
    tie = 0
    while frontier:
        _, _, cur = heapq.heappop(frontier)
        if cur in closed:
            continue                                  # stale entry; a cheaper route won
        closed.add(cur)
        if cur == goal:
            path = reconstruct(came_from, goal)
            return SearchResult(start, goal, path, g_score[goal], len(closed), g_score[goal],
                                manhattan(start, goal))
        for nxt in world.neighbors(cur):
            new_g = g_score[cur] + costs[world.terrain(nxt)]
            if nxt not in g_score or new_g < g_score[nxt]:
                g_score[nxt] = new_g
                came_from[nxt] = cur
                tie += 1
                heapq.heappush(frontier, (new_g + manhattan(nxt, goal), tie, nxt))
    return SearchResult(start, goal, [], None, len(closed), None, manhattan(start, goal))


def dijkstra_costs(world, start, costs=TERRAIN_COST):
    """Cheapest travel cost from start to EVERY reachable cell (one search instead of one
    A* per candidate). The Boss uses this to compare ambush cells quickly."""
    dist = {start: 0}
    frontier = [(0, start)]
    while frontier:
        d, cur = heapq.heappop(frontier)
        if d > dist[cur]:
            continue
        for nxt in world.neighbors(cur):
            nd = d + costs[world.terrain(nxt)]
            if nd < dist.get(nxt, float("inf")):
                dist[nxt] = nd
                heapq.heappush(frontier, (nd, nxt))
    return dist
