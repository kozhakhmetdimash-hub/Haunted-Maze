# Haunted Maze: Design Document

**Dimash Kozhakhmet · Ms. Qui · Unit 3 Project · Level: Advanced (2-gram Markov prediction)**

## 1. Objectives

**Player objective:** collect half of the candy in the maze to unlock the exit, then reach it without losing all 3 lives.

**AI objectives** (what the project needs to show):

1. Build a different, fully reachable maze every game (DFS recursive backtracking).
2. Let the player's probability settings change what spawns in the world.
3. Run small ghosts on a 4-state FSM that navigates with A*.
4. Learn the player's movement habits with 1st- and 2nd-order Markov models.
5. Have a Boss that uses those predictions to ambush instead of just chasing.
6. Make every AI decision visible and explainable in Debug Mode.

## 2. Game rules

| Thing | Rule |
|---|---|
| Lives | 3. You lose one when touched by a ghost or the Boss, or when you step on poison. After a hit, everyone goes back to spawn and you get 2 seconds of safety. |
| Candy | +10 points. Collecting `round(0.5 × spawned candy)` opens the exit. |
| Potion | Ghosts FLEE for 6 seconds. Touching a fleeing ghost banishes it (+50 points). The Boss isn't affected. |
| Spider | Stuck for 1.5 seconds. |
| Poison | −1 life. |
| Mud / thorns | Cost 2 / 3. Moving through them takes 2× / 3× longer for everyone, and A* plans around them. |
| Win / lose | Reach the open exit → win. 0 lives → lose. R restarts with a new maze. |

**Speeds** (frames per floor cell): player 8, Boss 11, ghost 13 (16 while fleeing). The player is the fastest, so the Boss has to predict and cut you off. Chasing alone usually won't catch you.

## 3. Assets

There are no external files. Everything is drawn with Pygame shapes so the web build stays small and has no licensing issues:

- **Player:** pumpkin kid (orange circle and stem). It blinks while invulnerable and has a purple aura while a potion is active.
- **Ghosts:** Wisp (light blue) and Shade (lavender). They turn dark blue with white eyes while fleeing.
- **Boss:** the Pumpkin King, a big red jack-o'-lantern with a flickering face.
- **Items:** wrapped candy, purple potion, black spider, green poison skull.
- **Terrain:** dark floor, brown mud, green thorns, and an exit portal ring.

## 4. World generation

1. **DFS recursive backtracking** carves a perfect maze. It uses an explicit stack, which is the same algorithm without Python's recursion limit.
2. **Add loops:** 12% of the walls that separate two corridors are removed. A perfect maze has only one route between any two cells, which would make prediction and ambushing pointless.
3. **Terrain:** short random walks paint 6 mud patches and 4 thorn patches.
4. **Validation:** a BFS from the start finds every reachable cell. The exit goes on the farthest one, enemy spawns go at least 14 steps away, and items only spawn on reachable cells at least 3 steps from the start.
5. **Probability spawning:** each eligible cell gets one roll `r`. With probabilities stacked in order (candy, potion, spider, poison), `r` falls into one item's band or into "nothing". The total is capped at 60%.

## 5. AI Design Diagram

![AI design diagram](ai_design_diagram.png)

### Small ghost FSM

| State | Navigation (A*) | Leaves when |
|---|---|---|
| PATROL | to a random cell within 8 of its spawn | sees player → CHASE · potion → FLEE |
| CHASE | to the player's cell. Re-plans only when the player enters a new cell | no sight for 2 s → SEARCH · potion → FLEE |
| SEARCH | to the last known player cell, then looks around for 2 s | sees player → CHASE · nothing → PATROL · potion → FLEE |
| FLEE | to the nearby cell farthest from the player | potion ends → PATROL |

"Sees" means a straight corridor with no walls between, up to 7 cells away, or within 2 cells (it can hear you).

### Boss decision pipeline

| Step | What happens | Code |
|---|---|---|
| 1. Observe | The player's move direction is recorded when they enter a new cell | `main.update_play` → `model.observe` |
| 2. Update model | `counts1[last][next] += 1`, `counts2[(prev, last)][next] += 1` | `MarkovPredictor.observe` |
| 3. Predict | Beam search 8 steps ahead, keeping the 6 most likely futures. Uses the 2-gram model if its context has been seen ≥3 times, otherwise 1st-order | `predict_paths` |
| 4. Candidates | Every cell on a predicted future. `p` = chance the player passes through it, `t` = first step they'd be there | `Boss.decide` |
| 5. Evaluate | `U = 40p − 0.6·cost − 4·late`, where `cost` comes from one Dijkstra flood out of the Boss | `Candidate` |
| 6. Select | Highest U wins. "Chase the player's current cell" is always a candidate too | `Boss.decide` |
| 7. Navigate | A* to the target, then wait (lurk) up to 3 s | `astar`, `Boss.update` |
| 8. Re-evaluate | Runs again every time the player enters a new cell, or after lurking | `Boss.update` |

**Boss states:** STALK (fewer than 6 moves seen, so it just uses A* to the player) → AMBUSH (the pipeline above) → POUNCE (player within 4 A* steps, so it goes straight for them).

## 6. Debug Mode (F / TAB)

- **On the maze:** each ghost's state label, path and target ✕, and a red line when it can see you. The Boss's predicted cells (brighter = more likely), the most likely predicted route, the top 5 candidates (numbered), its chosen target (red ring) and its A* path. Probability arrows on the player for the next move.
- **In the panel:** the reason for each state, the Boss's A* stats (cost, path length, nodes explored, h at the start), the candidate table (cell, t, p, cost, late, utility), recent moves, which Markov model is being used, the next-move distribution, accuracy for both models (overall and at junctions), and the 4×4 first-order count matrix.

## 7. Extension: 2-gram prediction

A 1st-order model can't tell "going up after a turn" apart from "going up after going up twice." The 2-gram model can. I tested both with simulated players. When the habit depended on the last two moves, the 2-gram model guessed correctly at **66%** of junctions vs. **55%** for 1st-order (1,960 junction choices). When the habit depended only on the last move, the two models tied, because the 2-gram falls back to the 1st-order model whenever it doesn't have enough data.
