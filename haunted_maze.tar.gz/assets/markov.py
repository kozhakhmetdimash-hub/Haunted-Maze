"""Markov models of the player's movement.

States are move directions (U, D, L, R).
  First order : P(next | last move)                  counts1[last][next]
  Second order: P(next | move before last, last move) counts2[(prev, last)][next]   <- 2-gram extension

Prediction uses the second-order model when its context has been seen at least
SECOND_ORDER_MIN times; otherwise it backs off to the first-order model, and with no data
at all it uses a uniform guess. Only directions that are open at the player's cell count,
so the model never predicts walking into a wall."""
from config import DIRS, DIR_NAMES, SECOND_ORDER_MIN, PREDICT_HORIZON, BEAM_WIDTH


class MarkovPredictor:
    def __init__(self):
        self.counts1 = {a: {b: 0 for b in DIR_NAMES} for a in DIR_NAMES}
        self.counts2 = {}
        self.history = []                 # every move the player has made
        self.observations = 0
        # accuracy: did each model's top guess match the move that actually happened?
        self.hits = {"1st": 0, "2nd": 0}
        self.tests = 0
        self.pending = None               # guesses made at the current cell, checked on the next move
        # junctions (3+ open exits) are where a guess is actually hard, so they get their own score
        self.junction = {"tests": 0, "1st": 0, "2nd": 0}

    # ---------------- learning ----------------
    def observe(self, direction):
        if self.pending:
            self.tests += 1
            for model in ("1st", "2nd"):
                if self.pending[model] == direction:
                    self.hits[model] += 1
            if self.pending["junction"]:
                self.junction["tests"] += 1
                for model in ("1st", "2nd"):
                    self.junction[model] += self.pending[model] == direction
            self.pending = None
        if len(self.history) >= 1:
            self.counts1[self.history[-1]][direction] += 1
        if len(self.history) >= 2:
            ctx = (self.history[-2], self.history[-1])
            row = self.counts2.setdefault(ctx, {b: 0 for b in DIR_NAMES})
            row[direction] += 1
        self.history.append(direction)
        self.observations += 1

    def make_guesses(self, valid):
        """Called once the player has arrived on a new cell: lock in each model's top guess."""
        last = self.history[-1:]
        two = tuple(self.history[-2:])
        d1 = self.first_order(last[0] if last else None, valid)
        d2 = self.second_order(two if len(two) == 2 else None, valid)
        # if the 2-gram context isn't trusted yet, the 2nd-order guess backs off to the 1st-order one
        self.pending = {"1st": argmax(d1), "2nd": argmax(d2 if d2 is not None else d1),
                        "junction": len(valid) >= 3}

    def accuracy(self, model):
        return self.hits[model] / self.tests if self.tests else None

    # ---------------- distributions ----------------
    def first_order(self, last, valid):
        if last is None:
            return uniform(valid)
        return normalize({d: self.counts1[last][d] for d in valid}, valid)

    def second_order(self, ctx, valid):
        """None if this 2-gram context hasn't been seen enough to trust."""
        if ctx is None or ctx not in self.counts2:
            return None
        row = self.counts2[ctx]
        if sum(row[d] for d in valid) < SECOND_ORDER_MIN:
            return None
        return normalize({d: row[d] for d in valid}, valid)

    def distribution(self, ctx, valid):
        """(distribution, which model produced it)."""
        if len(ctx) == 2:
            d2 = self.second_order(tuple(ctx), valid)
            if d2 is not None:
                return d2, "2nd-order"
        if len(ctx) >= 1:
            return self.first_order(ctx[-1], valid), "1st-order"
        return uniform(valid), "uniform"

    # ---------------- looking ahead ----------------
    def predict_paths(self, world, cell, horizon=PREDICT_HORIZON, width=BEAM_WIDTH):
        """Beam search over the model: roll the player forward one step at a time, keeping the
        `width` most probable futures. Returns steps[t] = list of (cell, probability, path)
        for t = 1..horizon."""
        beams = [(1.0, cell, tuple(self.history[-2:]), [cell])]
        steps = {}
        for t in range(1, horizon + 1):
            grown = []
            for prob, cur, ctx, path in beams:
                valid = valid_dirs(world, cur)
                dist, _ = self.distribution(list(ctx), valid)
                for d, p in dist.items():
                    if p <= 0:
                        continue
                    dx, dy = DIRS[d]
                    nxt = (cur[0] + dx, cur[1] + dy)
                    grown.append((prob * p, nxt, (ctx + (d,))[-2:], path + [nxt]))
            grown.sort(key=lambda b: -b[0])
            beams = grown[:width]
            steps[t] = [(c, p, path) for p, c, _, path in beams]
        return steps


def valid_dirs(world, cell):
    out = []
    for d in DIR_NAMES:
        dx, dy = DIRS[d]
        if world.walkable((cell[0] + dx, cell[1] + dy)):
            out.append(d)
    return out


def uniform(valid):
    return {d: 1 / len(valid) for d in valid} if valid else {}


def normalize(counts, valid):
    """Add-one (Laplace) smoothing so a move the player hasn't made yet is unlikely, not impossible."""
    total = sum(counts.values()) + len(valid)
    return {d: (counts[d] + 1) / total for d in valid}


def argmax(dist):
    return max(dist, key=lambda d: (dist[d], d)) if dist else None
