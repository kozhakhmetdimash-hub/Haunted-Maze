"""Procedural world: DFS recursive-backtracking maze + weighted terrain + probability-based items."""
import random
from collections import deque

from config import (COLS, ROWS, WALL, FLOOR, MUD, THORNS, MUD_PATCHES, THORN_PATCHES,
                    EXTRA_OPENINGS, ITEM_ORDER, CANDY, CANDY_NEEDED_FRACTION)


def carve_maze(cols, rows, rng):
    """DFS recursive backtracking. Uses an explicit stack instead of Python recursion
    (same algorithm, but it can't hit Python's recursion limit)."""
    grid = [[WALL] * cols for _ in range(rows)]
    grid[1][1] = FLOOR
    stack = [(1, 1)]
    while stack:
        x, y = stack[-1]
        unvisited = []
        for dx, dy in ((2, 0), (-2, 0), (0, 2), (0, -2)):
            nx, ny = x + dx, y + dy
            if 0 < nx < cols - 1 and 0 < ny < rows - 1 and grid[ny][nx] == WALL:
                unvisited.append((nx, ny))
        if unvisited:
            nx, ny = rng.choice(unvisited)
            grid[(y + ny) // 2][(x + nx) // 2] = FLOOR     # knock down the wall between
            grid[ny][nx] = FLOOR
            stack.append((nx, ny))                         # "recurse" into the new cell
        else:
            stack.pop()                                    # dead end: backtrack
    return grid


def add_loops(grid, rng, fraction):
    """A perfect maze has one route between any two cells, so there's nothing to predict
    or ambush. Removing a few walls that separate two corridors creates loops."""
    candidates = []
    for y in range(1, ROWS - 1):
        for x in range(1, COLS - 1):
            if grid[y][x] != WALL:
                continue
            horizontal = grid[y][x - 1] != WALL and grid[y][x + 1] != WALL
            vertical = grid[y - 1][x] != WALL and grid[y + 1][x] != WALL
            if horizontal != vertical:          # exactly one of them: a thin wall between corridors
                candidates.append((x, y))
    rng.shuffle(candidates)
    for x, y in candidates[:int(len(candidates) * fraction)]:
        grid[y][x] = FLOOR


def paint_terrain(grid, rng):
    floor = [(x, y) for y in range(ROWS) for x in range(COLS) if grid[y][x] == FLOOR]
    for terrain, patches, size in ((MUD, MUD_PATCHES, 6), (THORNS, THORN_PATCHES, 4)):
        for _ in range(patches):
            x, y = rng.choice(floor)
            for _ in range(size):
                grid[y][x] = terrain
                steps = [(x + dx, y + dy) for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))
                         if grid[y + dy][x + dx] != WALL]
                x, y = rng.choice(steps)


def walkable(grid, cell):
    x, y = cell
    return 0 <= x < COLS and 0 <= y < ROWS and grid[y][x] != WALL


def open_neighbors(grid, cell):
    x, y = cell
    for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
        n = (x + dx, y + dy)
        if walkable(grid, n):
            yield n


def bfs_steps(grid, start):
    """Step distance from start to every reachable cell (used to validate spawns)."""
    dist = {start: 0}
    queue = deque([start])
    while queue:
        cur = queue.popleft()
        for n in open_neighbors(grid, cur):
            if n not in dist:
                dist[n] = dist[cur] + 1
                queue.append(n)
    return dist


class World:
    """Everything that is generated before play: grid, terrain, items and spawn points."""

    def __init__(self, seed, probs):
        self.seed = seed
        self.rng = random.Random(seed)
        self.grid = carve_maze(COLS, ROWS, self.rng)
        add_loops(self.grid, self.rng, EXTRA_OPENINGS)
        paint_terrain(self.grid, self.rng)

        self.start = (1, 1)
        self.grid[1][1] = FLOOR
        self.reach = bfs_steps(self.grid, self.start)       # every reachable cell + its distance
        # the exit goes on the reachable cell farthest from the start
        self.exit = max(self.reach, key=lambda c: (self.reach[c], c))
        self.grid[self.exit[1]][self.exit[0]] = FLOOR

        far = [c for c, d in self.reach.items() if d >= 14 and c != self.exit]
        self.layout_rng = random.Random(seed * 7 + 1)
        self.ghost_spawns = self.layout_rng.sample(far, 2)
        mid = [c for c in far if c not in self.ghost_spawns and abs(c[0] - COLS // 2) + abs(c[1] - ROWS // 2) < 8]
        self.boss_spawn = self.layout_rng.choice(mid or far)
        self.spawn_items(probs)

    def spawn_items(self, probs):
        """Roll once per eligible cell. The probabilities the player chose decide what appears,
        so changing them really changes the world. Re-rolling uses the same seed, so the preview
        only changes because the probabilities changed."""
        rng = random.Random(self.seed * 31 + 5)
        reserved = {self.start, self.exit, self.boss_spawn, *self.ghost_spawns}
        self.items = {}
        self.eligible = 0
        for cell in sorted(self.reach):
            if cell in reserved or self.reach[cell] < 3:       # keep the start area safe
                continue
            self.eligible += 1
            r = rng.random()
            total = 0.0
            for kind in ITEM_ORDER:
                total += probs[kind]
                if r < total:
                    self.items[cell] = kind
                    break
        self.candy_total = sum(1 for k in self.items.values() if k == CANDY)
        self.candy_needed = round(self.candy_total * CANDY_NEEDED_FRACTION)

    def count(self, kind):
        return sum(1 for k in self.items.values() if k == kind)

    def terrain(self, cell):
        return self.grid[cell[1]][cell[0]]

    def walkable(self, cell):
        return walkable(self.grid, cell)

    def neighbors(self, cell):
        return open_neighbors(self.grid, cell)
