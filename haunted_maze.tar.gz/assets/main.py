"""Haunted Maze: Unit 3 Project (Advanced: 2-gram Markov prediction).

Run on desktop:  python main.py
Build for web:   pygbag haunted_maze      (run from the folder above this one)
"""
import asyncio
import random
import sys

import pygame

from config import (WIDTH, HEIGHT, GRID_W, GRID_H, PANEL_W, BAR_H, FPS, DEFAULT_PROB, ITEM_ORDER,
                    ITEM_INFO, PROB_STEP, PROB_MAX_EACH, PROB_MAX_TOTAL, CANDY, POTION, SPIDER,
                    POISON, POTION_FRAMES, WEB_FRAMES, HIT_GRACE_FRAMES, GHOST_COLORS, BG, PANEL_BG,
                    TEXT, DIM, ACCENT, GOOD, BAD, PLAYER_C)
from maze import World
from agents import Player
from ghost import Ghost, FLEE
from boss import Boss
from markov import MarkovPredictor, valid_dirs
from render import draw_world, draw_items, draw_player, draw_ghost, draw_boss, text
from debug import draw_overlay, draw_panel

KEY_DIRS = {pygame.K_UP: "U", pygame.K_w: "U", pygame.K_DOWN: "D", pygame.K_s: "D",
            pygame.K_LEFT: "L", pygame.K_a: "L", pygame.K_RIGHT: "R", pygame.K_d: "R"}
WEB = sys.platform == "emscripten"


class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Haunted Maze")
        self.clock = pygame.time.Clock()
        self.big = pygame.font.Font(None, 64)
        self.mid = pygame.font.Font(None, 30)
        self.font = pygame.font.Font(None, 22)
        self.small = pygame.font.Font(None, 18)
        self.probs = dict(DEFAULT_PROB)
        self.selected = 0
        self.debug = False
        self.running = True
        self.scene = "title"
        self.frame_no = 0
        self.new_world()

    # ---------------- setup ----------------
    def new_world(self, seed=None):
        self.seed = seed if seed is not None else random.randrange(100000)
        self.world = World(self.seed, self.probs)

    def adjust_prob(self, kind, delta):
        others = sum(v for k, v in self.probs.items() if k != kind)
        value = round(self.probs[kind] + delta, 2)
        value = max(0.0, min(PROB_MAX_EACH, value, round(PROB_MAX_TOTAL - others, 2)))
        self.probs[kind] = value
        self.world.spawn_items(self.probs)          # same maze, re-rolled items: see the effect live

    def start_game(self):
        w = self.world
        w.spawn_items(self.probs)
        self.player = Player(w.start)
        self.model = MarkovPredictor()
        rng = random.Random(self.seed + 99)
        self.ghosts = [Ghost("Wisp", w.ghost_spawns[0], GHOST_COLORS[0], rng),
                       Ghost("Shade", w.ghost_spawns[1], GHOST_COLORS[1], rng)]
        self.boss = Boss(w.boss_spawn)
        self.want = None
        self.message, self.message_t = "Collect candy, then reach the exit!", 3 * FPS
        self.play_frames = 0
        self.catches = {"ghost": 0, "boss": 0}
        self.scene = "play"

    # ---------------- input ----------------
    def handle(self, event):
        if event.type == pygame.QUIT:
            self.running = False
            return
        if event.type != pygame.KEYDOWN:
            return
        k = event.key
        if k in (pygame.K_f, pygame.K_TAB):
            self.debug = not self.debug
        if self.scene == "title":
            if k in (pygame.K_RETURN, pygame.K_SPACE):
                self.scene = "setup"
            elif k == pygame.K_ESCAPE and not WEB:
                self.running = False
        elif self.scene == "setup":
            if k in (pygame.K_UP, pygame.K_w):
                self.selected = (self.selected - 1) % len(ITEM_ORDER)
            elif k in (pygame.K_DOWN, pygame.K_s):
                self.selected = (self.selected + 1) % len(ITEM_ORDER)
            elif k in (pygame.K_LEFT, pygame.K_a):
                self.adjust_prob(ITEM_ORDER[self.selected], -PROB_STEP)
            elif k in (pygame.K_RIGHT, pygame.K_d):
                self.adjust_prob(ITEM_ORDER[self.selected], PROB_STEP)
            elif k == pygame.K_n:
                self.new_world()
            elif k in (pygame.K_RETURN, pygame.K_SPACE):
                self.start_game()
            elif k == pygame.K_ESCAPE:
                self.scene = "title"
        elif self.scene == "play":
            if k in KEY_DIRS:
                self.want = KEY_DIRS[k]
            elif k == pygame.K_ESCAPE:
                self.scene = "setup"
        elif self.scene in ("win", "lose"):
            if k in (pygame.K_r, pygame.K_RETURN):
                self.new_world()
                self.scene = "setup"
            elif k == pygame.K_ESCAPE and not WEB:
                self.running = False

    def held_direction(self):
        keys = pygame.key.get_pressed()
        held = [d for key, d in KEY_DIRS.items() if keys[key]]
        if self.want in held:
            return self.want
        return held[0] if held else None

    # ---------------- game update ----------------
    def update_play(self):
        w, p = self.world, self.player
        self.play_frames += 1
        p.tick()

        moved = p.try_step(w, self.held_direction())
        if moved:
            # 1-2. observe the move and update the Markov model, then lock in guesses for the next move
            self.model.observe(moved)
            self.model.make_guesses(valid_dirs(w, p.cell))
            self.pick_up(p.cell)

        for g in self.ghosts:
            g.update(w, p, bool(moved))
        self.boss.update(w, p, self.model, bool(moved))   # 3-8 happen inside the Boss
        self.check_collisions()

        if p.cell == w.exit and p.candy >= w.candy_needed:
            self.scene = "win"
        elif p.lives <= 0:
            self.scene = "lose"
        if self.message_t:
            self.message_t -= 1

    def pick_up(self, cell):
        p, kind = self.player, self.world.items.pop(cell, None)
        if kind == CANDY:
            p.candy += 1
            p.score += 10
            if p.candy == self.world.candy_needed:
                self.say("Enough candy! The exit is open.")
        elif kind == POTION:
            p.potion = POTION_FRAMES
            self.say("Potion! Ghosts flee. Touch them to banish.")
        elif kind == SPIDER:
            p.stuck = WEB_FRAMES
            self.say("Caught in a spider web!")
        elif kind == POISON:
            p.lives -= 1
            self.say("Poisoned! -1 life")

    def say(self, msg):
        self.message, self.message_t = msg, 2 * FPS

    def touching(self, npc):
        p = self.player
        swapped = p.cell == npc.prev and npc.cell == p.prev and p.cell != p.prev
        return p.cell == npc.cell or swapped

    def check_collisions(self):
        p = self.player
        for g in self.ghosts:
            if self.touching(g):
                if g.state == FLEE:
                    g.banish()
                    p.score += 50
                    self.say(f"{g.name} banished! +50")
                elif not p.grace:
                    self.lose_life(f"{g.name} got you!", "ghost")
                    return
        if self.touching(self.boss) and not p.grace:
            self.lose_life("The Pumpkin King ambushed you!", "boss")

    def lose_life(self, msg, who):
        p = self.player
        p.lives -= 1
        self.catches[who] += 1
        p.cell = p.prev = self.world.start
        p.move_left, p.stuck = 0, 0
        p.grace = HIT_GRACE_FRAMES
        for g in self.ghosts:
            g.banish()
        self.boss.reset()
        self.say(msg)

    # ---------------- drawing ----------------
    def draw(self):
        self.screen.fill(BG)
        if self.scene == "title":
            self.draw_title()
        elif self.scene == "setup":
            self.draw_setup()
        else:
            self.draw_play()
            if self.scene in ("win", "lose"):
                self.draw_end()
        pygame.display.flip()

    def draw_title(self):
        s, cx = self.screen, WIDTH // 2
        text(s, self.big, "HAUNTED MAZE", (cx, 150), ACCENT, center=True)
        text(s, self.mid, "Collect candy, dodge ghosts, and outsmart the Pumpkin King.", (cx, 215), TEXT, center=True)
        lines = ["The ghosts run on a state machine and find their way with A*.",
                 "The Pumpkin King learns how you move (2-gram Markov model)",
                 "and waits for you where it thinks you're going.",
                 "", "Press F or TAB at any time to see what the AI is thinking.",
                 "", "ENTER to start"]
        y = 280
        for line in lines:
            text(s, self.font, line, (cx, y), DIM if line != "ENTER to start" else GOOD, center=True)
            y += 28

    def draw_setup(self):
        s, w = self.screen, self.world
        draw_world(s, w, False, self.frame_no)
        draw_items(s, w, self.frame_no)
        pygame.draw.rect(s, PANEL_BG, (GRID_W, 0, PANEL_W, HEIGHT))
        x0 = GRID_W + 14
        y = text(s, self.mid, "WORLD SETUP", (x0, 12), ACCENT) + 6
        y = text(s, self.small, "Set how likely each item is on every open cell.", (x0, y), DIM)
        y = text(s, self.small, "The preview on the left re-rolls when you change one.", (x0, y), DIM) + 12
        for i, kind in enumerate(ITEM_ORDER):
            name, role, effect = ITEM_INFO[kind]
            sel = i == self.selected
            color = (GOOD if role == "reward" else BAD) if sel else DIM
            y = text(s, self.font, f"{'>' if sel else ' '} {name} ({role})", (x0, y), color)
            bar = pygame.Rect(x0 + 14, y + 3, 200, 10)
            pygame.draw.rect(s, (50, 44, 66), bar)
            pygame.draw.rect(s, color, (bar.x, bar.y, int(200 * self.probs[kind] / PROB_MAX_EACH), 10))
            text(s, self.font, f"{self.probs[kind]:.0%}", (bar.right + 10, y - 1), TEXT)
            y += 16
            expected = self.probs[kind] * w.eligible
            y = text(s, self.small, f"   {effect}", (x0, y), DIM)
            y = text(s, self.small, f"   expected {expected:.1f}   spawned {w.count(kind)}", (x0, y), TEXT) + 10
        y += 4
        y = text(s, self.small, f"Open cells rolled: {w.eligible}   seed {self.seed}", (x0, y), DIM)
        y = text(s, self.small, f"Candy needed to open the exit: {w.candy_needed}", (x0, y), ACCENT) + 14
        for line in ["UP/DOWN  pick an item", "LEFT/RIGHT  change its probability",
                     "N  new maze", "ENTER  play"]:
            y = text(s, self.font, line, (x0, y), TEXT) + 2
        self.draw_bar("World setup: change the probabilities, then press ENTER")

    def draw_play(self):
        s, w, p = self.screen, self.world, self.player
        draw_world(s, w, p.candy >= w.candy_needed, self.frame_no)
        draw_items(s, w, self.frame_no)
        if self.debug:
            draw_overlay(s, self, self.small)
        for g in self.ghosts:
            draw_ghost(s, g, self.frame_no, g.state == FLEE)
        draw_boss(s, self.boss, self.frame_no)
        draw_player(s, p, self.frame_no)

        pygame.draw.rect(s, PANEL_BG, (GRID_W, 0, PANEL_W, HEIGHT))
        if self.debug:
            draw_panel(s, self, self.font, self.small)
        else:
            self.draw_hud()
        status = (f"Lives {p.lives}   Score {p.score}   Candy {p.candy}/{w.candy_needed}"
                  f"   Time {self.play_frames // FPS}s")
        if p.potion:
            status += f"   Potion {p.potion // FPS + 1}s"
        self.draw_bar(self.message if self.message_t else status)

    def draw_hud(self):
        s, p, w = self.screen, self.player, self.world
        x0 = GRID_W + 14
        y = text(s, self.mid, "HAUNTED MAZE", (x0, 12), ACCENT) + 10
        for label, value, color in (("Lives", p.lives, BAD), ("Score", p.score, TEXT),
                                    ("Candy", f"{p.candy} / {w.candy_needed}", PLAYER_C)):
            text(s, self.font, label, (x0, y), DIM)
            y = text(s, self.font, str(value), (x0 + 90, y), color) + 6
        exit_txt = "OPEN - go!" if p.candy >= w.candy_needed else "locked"
        y = text(s, self.font, f"Exit: {exit_txt}", (x0, y), GOOD if p.candy >= w.candy_needed else DIM) + 16
        for line, color in (("Candy  - collect to open the exit", (255, 200, 60)),
                            ("Potion - ghosts flee for 6 s", (170, 80, 255)),
                            ("Spider - stuck for 1.5 s", (200, 200, 200)),
                            ("Poison - lose a life", (120, 230, 60)),
                            ("Mud / thorns - slow (cost 2 / 3)", (160, 120, 80)),
                            ("", TEXT),
                            ("Ghosts chase you when they see you.", DIM),
                            ("The Pumpkin King learns your habits", DIM),
                            ("and waits for you where you're going.", DIM),
                            ("", TEXT),
                            ("Arrows/WASD move    F/TAB debug", TEXT),
                            ("ESC back to setup", TEXT)):
            y = text(s, self.small, line, (x0, y), color) + 4

    def draw_bar(self, msg):
        pygame.draw.rect(self.screen, (10, 8, 16), (0, GRID_H, WIDTH, BAR_H))
        text(self.screen, self.font, msg, (14, GRID_H + 14), ACCENT)

    def draw_end(self):
        shade = pygame.Surface((GRID_W, GRID_H), pygame.SRCALPHA)
        shade.fill((0, 0, 0, 170))
        self.screen.blit(shade, (0, 0))
        cx, cy = GRID_W // 2, GRID_H // 2
        won = self.scene == "win"
        text(self.screen, self.big, "YOU ESCAPED!" if won else "GAME OVER", (cx, cy - 70), GOOD if won else BAD, center=True)
        m, p = self.model, self.player
        a1, a2 = m.accuracy("1st"), m.accuracy("2nd")
        acc = f"Prediction accuracy: 1st-order {a1:.0%}, 2nd-order {a2:.0%}" if a1 is not None else ""
        for i, line in enumerate([f"Score {p.score}   Time {self.play_frames // FPS}s",
                                  f"Caught by ghosts {self.catches['ghost']}   by the Pumpkin King {self.catches['boss']}",
                                  acc, "R  play again (new maze)" + ("" if WEB else "    ESC  quit")]):
            text(self.screen, self.font, line, (cx, cy - 10 + i * 28), TEXT, center=True)

    # ---------------- loop ----------------
    def tick(self):
        for event in pygame.event.get():
            self.handle(event)
        if self.scene == "play":
            self.update_play()
        self.frame_no += 1
        self.draw()
        self.clock.tick(FPS)


async def main():
    game = Game()
    while game.running:
        game.tick()
        await asyncio.sleep(0)          # lets the browser run between frames (needed by pygbag)
    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
