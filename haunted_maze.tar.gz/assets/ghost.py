"""Small ghost NPC controlled by a finite state machine.

    PATROL --sees player--> CHASE --loses sight 2 s--> SEARCH --gives up--> PATROL
       ^                      ^                          |
       |                      +-------sees player--------+
    any state --player drinks potion--> FLEE --potion ends--> PATROL

Every state navigates with A*. CHASE and FLEE re-plan only when the player enters a new
cell (event-driven), not on a timer."""
from config import (GHOST_STEP, GHOST_FLEE_STEP, SIGHT_RANGE, HEAR_RANGE, LOSE_SIGHT_FRAMES,
                    SEARCH_LOOK_FRAMES, PATROL_RADIUS, COLS, ROWS)
from agents import PathFollower
from pathfinding import astar, manhattan

PATROL, CHASE, SEARCH, FLEE = "PATROL", "CHASE", "SEARCH", "FLEE"


def can_see(world, a, b):
    """Straight corridor line of sight (same row or column, no walls between), or close enough to hear."""
    if manhattan(a, b) <= HEAR_RANGE:
        return True
    if a[0] == b[0] and abs(a[1] - b[1]) <= SIGHT_RANGE:
        step = 1 if b[1] > a[1] else -1
        return all(world.walkable((a[0], y)) for y in range(a[1] + step, b[1], step))
    if a[1] == b[1] and abs(a[0] - b[0]) <= SIGHT_RANGE:
        step = 1 if b[0] > a[0] else -1
        return all(world.walkable((x, a[1])) for x in range(a[0] + step, b[0], step))
    return False


class Ghost(PathFollower):
    def __init__(self, name, cell, color, rng):
        super().__init__(cell, GHOST_STEP)
        self.name, self.color, self.rng = name, color, rng
        self.spawn = cell
        self.state = PATROL
        self.reason = "start"
        self.unseen = 0                 # frames since the player was last seen
        self.last_known = None
        self.look = 0                   # frames left looking around in SEARCH
        self.sees = False

    def change(self, state, reason):
        if state != self.state:
            self.state, self.reason = state, reason
            self.path = []              # force a new plan for the new state

    def banish(self):
        self.cell = self.prev = self.spawn
        self.move_left = 0
        self.path = []
        self.state, self.reason = PATROL, "banished"

    # ---------------- decisions ----------------
    def update(self, world, player, player_moved):
        self.sees = can_see(world, self.cell, player.cell)

        # 1. transitions
        if player.potion > 0:
            self.change(FLEE, "player has potion")
        elif self.state == FLEE:
            self.change(PATROL, "potion wore off")
        elif self.sees:
            self.unseen = 0
            self.last_known = player.cell
            self.change(CHASE, "saw player")
        elif self.state == CHASE:
            self.unseen += 1
            if self.unseen >= LOSE_SIGHT_FRAMES:
                self.change(SEARCH, "lost sight for 2 s")
                self.look = SEARCH_LOOK_FRAMES
        elif self.state == SEARCH and self.arrived:
            self.look -= 1
            if self.look <= 0:
                self.change(PATROL, "search found nothing")

        # 2. actions (each state picks an A* target)
        self.step_frames = GHOST_FLEE_STEP if self.state == FLEE else GHOST_STEP
        if self.state == PATROL and self.arrived:
            self.set_path(astar(world, self.cell, self.random_patrol_cell(world)))
        elif self.state == CHASE:
            if player_moved or not self.path:
                self.last_known = player.cell
                self.set_path(astar(world, self.cell, player.cell))
        elif self.state == SEARCH and self.arrived and self.target != self.last_known:
            self.set_path(astar(world, self.cell, self.last_known))
        elif self.state == FLEE and (player_moved or self.arrived):
            self.set_path(astar(world, self.cell, self.flee_cell(world, player.cell)))

        self.follow(world)

    def random_patrol_cell(self, world):
        options = [c for c in world.reach if manhattan(c, self.spawn) <= PATROL_RADIUS and c != self.cell]
        return self.rng.choice(options)

    def flee_cell(self, world, threat):
        """Pick the nearby cell that is farthest from the player."""
        near = [c for c in world.reach if manhattan(c, self.cell) <= 6]
        return max(near, key=lambda c: (manhattan(c, threat), -manhattan(c, self.cell)))
