"""Drawing for the maze, items and characters (no AI logic in here)."""
import math

import pygame

from config import (CELL, COLS, ROWS, WALL, MUD, THORNS, WALL_C, WALL_EDGE, FLOOR_C, MUD_C,
                    THORNS_C, EXIT_LOCKED, EXIT_OPEN, PLAYER_C, BOSS_C, CANDY, POTION, SPIDER,
                    POISON, TEXT)


def cell_center(cell):
    return cell[0] * CELL + CELL // 2, cell[1] * CELL + CELL // 2


def draw_world(surf, world, exit_open, frame):
    for y in range(ROWS):
        for x in range(COLS):
            t = world.grid[y][x]
            r = pygame.Rect(x * CELL, y * CELL, CELL, CELL)
            if t == WALL:
                pygame.draw.rect(surf, WALL_C, r)
                pygame.draw.rect(surf, WALL_EDGE, r, 1)
                continue
            pygame.draw.rect(surf, FLOOR_C, r)
            if t == MUD:
                pygame.draw.rect(surf, MUD_C, r.inflate(-2, -2), border_radius=6)
                for dx, dy in ((7, 8), (17, 12), (10, 19)):
                    pygame.draw.circle(surf, (70, 48, 30), (r.x + dx, r.y + dy), 2)
            elif t == THORNS:
                pygame.draw.rect(surf, THORNS_C, r.inflate(-2, -2), border_radius=4)
                c = (30, 56, 30)
                pygame.draw.line(surf, c, (r.x + 6, r.y + 6), (r.right - 6, r.bottom - 6), 2)
                pygame.draw.line(surf, c, (r.right - 6, r.y + 6), (r.x + 6, r.bottom - 6), 2)
    # exit portal
    cx, cy = cell_center(world.exit)
    color = EXIT_OPEN if exit_open else EXIT_LOCKED
    pulse = 2 * math.sin(frame / 10) if exit_open else 0
    pygame.draw.circle(surf, color, (cx, cy), int(CELL // 2 - 2 + pulse), 3)
    pygame.draw.circle(surf, color, (cx, cy), 5)


def draw_items(surf, world, frame):
    for cell, kind in world.items.items():
        cx, cy = cell_center(cell)
        if kind == CANDY:
            pygame.draw.polygon(surf, (255, 140, 30), [(cx - 11, cy - 5), (cx - 11, cy + 5), (cx - 5, cy)])
            pygame.draw.polygon(surf, (255, 140, 30), [(cx + 11, cy - 5), (cx + 11, cy + 5), (cx + 5, cy)])
            pygame.draw.circle(surf, (255, 200, 60), (cx, cy), 6)
        elif kind == POTION:
            pygame.draw.rect(surf, (200, 200, 220), (cx - 2, cy - 10, 4, 5))
            pygame.draw.circle(surf, (170, 80, 255), (cx, cy + 2), 7)
            pygame.draw.circle(surf, (230, 200, 255), (cx - 2, cy), 2)
        elif kind == SPIDER:
            for i in (-1, 1):
                for k in (-6, -2, 2, 6):
                    pygame.draw.line(surf, (20, 20, 20), (cx, cy + k // 2), (cx + i * 10, cy + k), 2)
            pygame.draw.circle(surf, (15, 15, 15), (cx, cy), 5)
            pygame.draw.circle(surf, (230, 40, 40), (cx - 2, cy - 2), 1)
            pygame.draw.circle(surf, (230, 40, 40), (cx + 2, cy - 2), 1)
        elif kind == POISON:
            bob = int(2 * math.sin(frame / 12 + cell[0]))
            pygame.draw.circle(surf, (120, 230, 60), (cx, cy + bob), 7)
            pygame.draw.circle(surf, (20, 40, 10), (cx - 3, cy - 1 + bob), 2)
            pygame.draw.circle(surf, (20, 40, 10), (cx + 3, cy - 1 + bob), 2)
            pygame.draw.line(surf, (20, 40, 10), (cx - 3, cy + 4 + bob), (cx + 3, cy + 4 + bob), 2)


def draw_player(surf, player, frame):
    if player.grace and (frame // 5) % 2:
        return                                          # blink while invulnerable
    cx, cy = player.pixel_pos()
    if player.potion:
        pygame.draw.circle(surf, (170, 80, 255), (cx, cy), CELL // 2 + 2, 2)
    pygame.draw.circle(surf, PLAYER_C, (cx, cy), CELL // 2 - 4)
    pygame.draw.rect(surf, (60, 140, 40), (cx - 2, cy - CELL // 2 + 1, 4, 5))
    for ex in (-4, 4):
        pygame.draw.polygon(surf, (40, 20, 0), [(cx + ex - 2, cy - 1), (cx + ex + 2, cy - 1), (cx + ex, cy - 5)])
    if player.stuck:
        for a in range(0, 360, 60):
            r = math.radians(a)
            pygame.draw.line(surf, (230, 230, 240), (cx, cy), (cx + 13 * math.cos(r), cy + 13 * math.sin(r)), 1)


def draw_ghost(surf, ghost, frame, fleeing):
    cx, cy = ghost.pixel_pos()
    cy += int(2 * math.sin(frame / 8 + ghost.spawn[0]))
    color = (90, 110, 255) if fleeing else ghost.color
    w, h = CELL - 8, CELL - 6
    body = pygame.Rect(0, 0, w, h)
    body.center = (cx, cy)
    pygame.draw.ellipse(surf, color, (body.x, body.y, w, h - 4))
    pygame.draw.rect(surf, color, (body.x, cy - 2, w, h // 2 - 1))
    for i in range(3):                                   # wavy hem
        pygame.draw.circle(surf, color, (body.x + 3 + i * (w - 6) // 2, body.bottom - 3), 3)
    eye = (255, 255, 255) if fleeing else (20, 20, 40)
    for ex in (-4, 4):
        pygame.draw.circle(surf, eye, (cx + ex, cy - 3), 3)


def draw_boss(surf, boss, frame):
    cx, cy = boss.pixel_pos()
    rad = CELL // 2 + 1
    pygame.draw.circle(surf, (120, 20, 30), (cx, cy), rad + 2)
    pygame.draw.circle(surf, BOSS_C, (cx, cy), rad)
    pygame.draw.rect(surf, (40, 90, 30), (cx - 3, cy - rad - 3, 6, 6))
    glow = (255, 230, 90) if (frame // 15) % 2 else (255, 180, 40)
    pygame.draw.polygon(surf, glow, [(cx - 8, cy - 2), (cx - 3, cy - 2), (cx - 5, cy - 7)])
    pygame.draw.polygon(surf, glow, [(cx + 8, cy - 2), (cx + 3, cy - 2), (cx + 5, cy - 7)])
    pts = [(cx - 9, cy + 3)]
    for i in range(1, 6):
        pts.append((cx - 9 + i * 3.6, cy + (8 if i % 2 else 4)))
    pts.append((cx + 9, cy + 3))
    pygame.draw.polygon(surf, glow, pts)


def text(surf, font, msg, pos, color=TEXT, center=False):
    img = font.render(msg, True, color)
    rect = img.get_rect(center=pos) if center else img.get_rect(topleft=pos)
    surf.blit(img, rect)
    return rect.bottom
